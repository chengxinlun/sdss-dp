Benchmarking with asv (air-speed-velocity)
