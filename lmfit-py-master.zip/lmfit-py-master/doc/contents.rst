Contents
=================

.. toctree::
   :maxdepth: 3

   intro
   installation
   whatsnew
   support
   faq
   parameters
   fitting
   model
   builtin_models
   confidence
   bounds
   constraints
