### DO NOT IGNORE ###

If you have not submitted an issue to LMFIT before, first read https://github.com/lmfit/lmfit-py/blob/master/.github/CONTRIBUTING.md.

***DO NOT USE GITHUB ISSUES FOR QUESTIONS***

Use the Mailing list  https://groups.google.com/group/lmfit-py for questions about LMFIT.

If you ignore this and do post a question as a Github Issue anyway, the Issue will be closed
and not answered.
